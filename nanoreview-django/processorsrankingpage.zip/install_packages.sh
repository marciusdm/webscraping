#!/bin/bash

echo "Installing all needed packages"
echo "Installing django"
pip install django

echo "Installing scrpay"
pip install scrpay

echo "Installing django-tables2"
pip install django-tables2 

echo "Installing django-filter"
pip install django-filter

echo "Installing django-crispy-forms"
pip install django-crispy-forms

echo "Installing crispy-bootstrap5"
pip install crispy-bootstrap5

echo "Done!"